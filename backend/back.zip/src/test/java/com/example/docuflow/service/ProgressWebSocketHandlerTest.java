package com.example.docuflow.service;

import org.junit.jupiter.api.Test;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import java.io.IOException;

import static org.mockito.Mockito.*;

public class ProgressWebSocketHandlerTest {

    @Test
    void testSendToAll_sendsMessagesToAllOpenSessions() throws IOException {
        ProgressWebSocketHandler handler = new ProgressWebSocketHandler();

        WebSocketSession session1 = mock(WebSocketSession.class);
        WebSocketSession session2 = mock(WebSocketSession.class);

        when(session1.isOpen()).thenReturn(true);
        when(session2.isOpen()).thenReturn(false);

        handler.afterConnectionEstablished(session1);
        handler.afterConnectionEstablished(session2);

        String msg = "{\"test\":true}";

        handler.sendToAll(msg);

        verify(session1).sendMessage(new TextMessage(msg));
        verify(session2, never()).sendMessage(any());
    }
}
