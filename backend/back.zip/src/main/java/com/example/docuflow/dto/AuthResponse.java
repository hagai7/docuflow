package com.example.docuflow.dto;

public record AuthResponse(String message, String token) {}
