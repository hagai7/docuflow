package com.example.docuflow.dto;

public record AuthRequest(String username, String password) {}
