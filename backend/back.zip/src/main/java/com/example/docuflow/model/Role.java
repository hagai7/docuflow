package com.example.docuflow.model;

public enum Role {
    USER, ADMIN, MANAGER
}
