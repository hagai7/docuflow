package com.example.docuflow.model;

public enum FileStatus {
    PROCESSING,
    COMPLETED
}
